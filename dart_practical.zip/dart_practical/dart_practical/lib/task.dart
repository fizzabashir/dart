import 'dart:io';
void main() {
  List<String> tasks = [];
  while (true) {
    print("\n1. View Tasks");
    print("2. Add Task");
    print("3. Dlt Task");
    print("4. Update Task");
    print("5. Exit");
    stdout.write("Enter your choice: ");
    String? choice = stdin.readLineSync();

    if (choice == '1') {
      print("\nTasks:");
      if (tasks.isEmpty) {
        print("No tasks available.");
      } 
      else {
        for (int i = 0; i < tasks.length; i++) {
          print("${i + 1}. ${tasks[i]}");
        }
      }
    } else if (choice == '2') {
      stdout.write("\nEnter new task: ");
      String? task = stdin.readLineSync();
      if (task != null && task.isNotEmpty) {
        tasks.add(task);
        print("Your Task has been added!");
      }
    } else if (choice == '3') {
      stdout.write("\nEnter task number to delete: ");
      int? num = int.tryParse(stdin.readLineSync() ?? '');
      if (num != null && num > 0 && num <= tasks.length) {
        tasks.removeAt(num - 1);
        print("Task deleted!");
      } else {
        print("Invalid task number.");
      }
          
    } else if (choice == '4') {
      stdout.write("\nEnter task number to update: ");
      int? num = int.tryParse(stdin.readLineSync() ?? '');
      if (num != null && num > 0 && num <= tasks.length)
       {
        stdout.write("Enter updated task: ");
        String? newTask = stdin.readLineSync();
        if (newTask != null && newTask.isNotEmpty) {
          tasks[num - 1] = newTask;
          print("Task updated!");
        }

      } else {
        print("Invalid task number.");
      }

    }
     else if (choice == '5') {
      print("\nGudbye!");
      break;
    } else {
      print("\nInvalid choice, try again.");
    }
  }
}


